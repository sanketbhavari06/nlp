import spacy
import string


nlp = spacy.load("en_core_web_sm")


with open("input.txt", "r") as file:
    text = file.read()

print("Original Text:\n", text)


doc = nlp(text)


tokens = [token.text for token in doc]
print("\nTokenized:\n", tokens)


tokens_no_punct = [token.text for token in doc if not token.is_punct]
print("\nAfter Punctuation Removal:\n", tokens_no_punct)

tokens_no_stop = [token.text for token in doc if not token.is_stop and not token.is_punct]
print("\nAfter Stop Word Removal:\n", tokens_no_stop)


lemmas = [token.lemma_ for token in doc if not token.is_stop and not token.is_punct]
print("\nLemmatized:\n", lemmas)
