

import nltk
import string
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer


nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('omw-1.4')


text = """
Natural Language Processing (NLP) is a sub-field of artificial intelligence (AI)
that focuses on the interaction between computers and humans through natural language.
The ultimate objective of NLP is to read, decipher, understand, and make sense of
the human languages in a manner that is valuable.
"""

print("Original Text:\n", text)


tokens = word_tokenize(text)
print("\n1. Tokenization:\n", tokens)


tokens_no_punct = [word for word in tokens if word not in string.punctuation]
print("\n2. After Punctuation Removal:\n", tokens_no_punct)

stop_words = set(stopwords.words('english'))
tokens_no_stop = [word for word in tokens_no_punct if word.lower() not in stop_words]
print("\n3. After Stop Word Removal:\n", tokens_no_stop)


stemmer = PorterStemmer()
stemmed_tokens = [stemmer.stem(word) for word in tokens_no_stop]
print("\n4. After Stemming:\n", stemmed_tokens)


lemmatizer = WordNetLemmatizer()
lemmatized_tokens = [lemmatizer.lemmatize(word.lower(), pos='v') for word in tokens_no_stop]
print("\n5. After Lemmatization:\n", lemmatized_tokens)
